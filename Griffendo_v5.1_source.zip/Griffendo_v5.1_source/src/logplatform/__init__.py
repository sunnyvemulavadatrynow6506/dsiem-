"""Windows log analytics platform."""
